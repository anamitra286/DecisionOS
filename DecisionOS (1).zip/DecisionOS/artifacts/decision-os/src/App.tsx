import { useEffect, useMemo, useState } from 'react';
import { ClerkProvider, Show, SignIn, SignUp } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import {
  ArrowRight,
  BarChart3,
  Bell,
  Brain,
  Check,
  ChevronRight,
  CircleHelp,
  Compass,
  History,
  Lightbulb,
  Menu,
  Plus,
  RotateCcw,
  Scale,
  Search,
  ShieldCheck,
  Sparkles,
  Target,
  ThumbsDown,
  ThumbsUp,
  TrendingUp,
  X,
} from 'lucide-react';
import { type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { Route, Router as WouterRouter, Switch, useLocation } from 'wouter';

type NavKey = 'workspace' | 'new' | 'history' | 'regret' | 'patterns' | 'suggestions';
type Outcome = 'good' | 'neutral' | 'bad';
type DecisionRecord = {
  id: string;
  title: string;
  context: string;
  options: string[];
  recommendation: number;
  selected?: number;
  accepted?: boolean;
  outcome?: Outcome;
  createdAt: string;
};

const initialRecord: DecisionRecord = {
  id: 'decision-01',
  title: 'Should I stay in my current role or take the studio offer?',
  context: 'I have grown quickly at my current company, but the studio role would give me more creative ownership. The pay is slightly lower and I would be joining a smaller team.',
  options: ['Stay in my current role', 'Take the studio offer'],
  recommendation: 1,
  createdAt: 'Today',
};

const starterHistory: DecisionRecord[] = [
  initialRecord,
  { id: 'decision-02', title: 'Move closer to the city or keep the extra space?', context: 'A shorter commute versus a home that feels like mine.', options: ['Move closer', 'Keep the space'], recommendation: 1, selected: 1, accepted: true, outcome: 'good', createdAt: 'Mar 14' },
  { id: 'decision-03', title: 'Say yes to the community board?', context: 'It would stretch my schedule, but connect me with people I admire.', options: ['Join the board', 'Protect my time'], recommendation: 0, selected: 1, accepted: false, outcome: 'neutral', createdAt: 'Feb 28' },
];

const agentData = [
  { name: 'Context', icon: Compass, color: 'lavender', summary: 'The real shape of the choice', text: 'This is less about a job title and more about choosing your next environment for growth. You are already asking for more authorship.' },
  { name: 'Preference', icon: Target, color: 'peach', summary: 'What you keep coming back to', text: 'Your notes point to creative ownership, a close team, and work you can point to with pride. Predictability is useful, but not your north star.' },
  { name: 'Trade-off', icon: Scale, color: 'mint', summary: 'What each path asks of you', text: 'The studio trades short-term financial comfort for a sharper learning curve and a stronger sense of authorship. The current role trades upside for stability.' },
  { name: 'Regret', icon: RotateCcw, color: 'butter', summary: 'Future-you looks back', text: 'You are more likely to regret staying from fear than leaving after a thoughtful check of the numbers. The window for this kind of leap is not infinite.' },
  { name: 'Devil’s Advocate', icon: CircleHelp, color: 'rose', summary: 'The useful objection', text: 'Creative ownership can hide messy boundaries. Ask for the studio’s runway, decision rights, and what “ownership” means in the first 90 days.' },
  { name: 'Decision', icon: Brain, color: 'indigo', summary: 'A clear next move', text: 'Take the studio offer — with one condition: confirm six months of runway and a written scope before you sign.' },
];

const navItems: { key: NavKey; label: string; icon: typeof Compass }[] = [
  { key: 'workspace', label: 'Active decision', icon: Target },
  { key: 'new', label: 'New decision', icon: Plus },
  { key: 'history', label: 'Decision history', icon: History },
  { key: 'regret', label: 'Regret tracking', icon: RotateCcw },
  { key: 'patterns', label: 'Decision patterns', icon: BarChart3 },
  { key: 'suggestions', label: 'Autonomous suggestions', icon: Lightbulb },
];

const queryClient = new QueryClient();
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: 'clerk',
  options: {
    logoPlacement: 'inside' as const,
    logoLinkUrl: basePath || '/',
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: '#6650D8',
    colorForeground: '#29213E',
    colorMutedForeground: '#716B7A',
    colorDanger: '#B94A44',
    colorBackground: '#FFFCF7',
    colorInput: '#FBF3E8',
    colorInputForeground: '#29213E',
    colorNeutral: '#DED5C9',
    fontFamily: 'Manrope, sans-serif',
    borderRadius: '14px',
  },
  elements: {
    rootBox: 'w-full flex justify-center',
    cardBox: 'bg-[#FFFCF7] rounded-[26px] w-[440px] max-w-full overflow-hidden shadow-[0_24px_70px_rgba(41,33,62,.12)]',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none',
    footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: 'display-font !text-[#29213E] !font-bold',
    headerSubtitle: '!text-[#716B7A]',
    socialButtonsBlockButtonText: '!text-[#29213E] !font-semibold',
    formFieldLabel: '!text-[#29213E] !font-semibold',
    footerActionLink: '!text-[#6650D8] !font-bold',
    footerActionText: '!text-[#716B7A]',
    dividerText: '!text-[#716B7A]',
    identityPreviewEditButton: '!text-[#6650D8]',
    formFieldSuccessText: '!text-[#28796A]',
    alertText: '!text-[#B94A44]',
    logoBox: 'h-12',
    logoImage: 'h-12 w-12 rounded-[14px]',
    socialButtonsBlockButton: '!border-[#DED5C9] !bg-[#FBF3E8] hover:!bg-[#F4E8D8]',
    formButtonPrimary: '!bg-[#6650D8] hover:!bg-[#5843C8] !shadow-lg !shadow-[#6650D8]/20',
    formFieldInput: '!border-[#DED5C9] !bg-[#FBF3E8] !text-[#29213E] focus:!border-[#6650D8] focus:!ring-[#6650D8]/20',
    footerAction: '!bg-transparent',
    dividerLine: '!bg-[#DED5C9]',
    alert: '!border-[#F0C8BD] !bg-[#FFF0EB]',
    otpCodeFieldInput: '!border-[#DED5C9] !bg-[#FBF3E8]',
    formFieldRow: 'mb-4',
    main: 'gap-5',
  },
};

function loadDecisions(): DecisionRecord[] {
  try {
    const stored = window.localStorage.getItem('decision-os-records');
    return stored ? JSON.parse(stored) as DecisionRecord[] : starterHistory;
  } catch {
    return starterHistory;
  }
}

function DecisionPortal() {
  const [activeNav, setActiveNav] = useState<NavKey>('workspace');
  const [records, setRecords] = useState<DecisionRecord[]>(loadDecisions);
  const [mobileNav, setMobileNav] = useState(false);
  const [modal, setModal] = useState<'suggestion' | 'clear' | null>(null);
  const [toast, setToast] = useState('');
  const active = records[0] ?? initialRecord;

  useEffect(() => {
    window.localStorage.setItem('decision-os-records', JSON.stringify(records));
  }, [records]);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(''), 2800);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const updateActive = (patch: Partial<DecisionRecord>) => {
    setRecords((current) => current.map((item, index) => index === 0 ? { ...item, ...patch } : item));
  };

  const addDecision = (title: string, context: string, options: string[]) => {
    const next: DecisionRecord = {
      id: `decision-${Date.now()}`,
      title,
      context,
      options,
      recommendation: 0,
      createdAt: 'Just now',
    };
    setRecords((current) => [next, ...current]);
    setActiveNav('workspace');
    setToast('Decision captured. Give me a moment to sort the signal from the noise.');
  };

  const selectOutcome = (outcome: Outcome) => {
    updateActive({ outcome });
    setToast(outcome === 'good' ? 'Logged. That signal will sharpen your future calls.' : 'Logged. No judgment — useful data is still useful.');
  };

  const navLabel = navItems.find((item) => item.key === activeNav)?.label ?? 'Active decision';

  return (
    <div className="noise app-shell min-h-[100dvh] md:flex">
      <aside className={`${mobileNav ? 'translate-x-0' : '-translate-x-full'} fixed inset-y-0 left-0 z-40 w-[286px] shrink-0 bg-[hsl(var(--sidebar))] text-[hsl(var(--sidebar-foreground))] transition-transform duration-300 md:relative md:translate-x-0`}>
        <div className="flex h-full flex-col px-5 py-6">
          <div className="flex items-center justify-between px-2">
            <button className="flex items-center gap-3 text-left" onClick={() => { setActiveNav('workspace'); setMobileNav(false); }} data-testid="button-logo">
              <span className="grid size-10 place-items-center rounded-[14px] bg-[hsl(var(--sidebar-primary))] text-[hsl(var(--sidebar-primary-foreground))] shadow-lg shadow-black/10"><Sparkles size={20} strokeWidth={2.5} /></span>
              <span><span className="display-font block text-[17px] font-bold tracking-[-.04em]">DecisionOS</span><span className="mono-font text-[9px] uppercase tracking-[.18em] text-[hsl(var(--sidebar-foreground)/.52)]">Think clearer</span></span>
            </button>
            <button className="rounded-lg p-2 text-[hsl(var(--sidebar-foreground)/.65)] md:hidden" onClick={() => setMobileNav(false)} data-testid="button-close-nav"><X size={18} /></button>
          </div>

          <div className="mt-12 px-3">
            <p className="mono-font mb-3 text-[10px] uppercase tracking-[.18em] text-[hsl(var(--sidebar-foreground)/.4)]">Your space</p>
            <nav className="space-y-1" aria-label="Main navigation">
              {navItems.map(({ key, label, icon: Icon }) => (
                <button key={key} onClick={() => { setActiveNav(key); setMobileNav(false); }} className={`group flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-[13px] transition-all ${activeNav === key ? 'bg-[hsl(var(--sidebar-accent))] text-[hsl(var(--sidebar-foreground))] shadow-sm' : 'text-[hsl(var(--sidebar-foreground)/.63)] hover:bg-[hsl(var(--sidebar-accent)/.65)] hover:text-[hsl(var(--sidebar-foreground))]'}`} data-testid={`button-nav-${key}`}>
                  <Icon size={17} strokeWidth={activeNav === key ? 2.3 : 1.8} className={activeNav === key ? 'text-[hsl(var(--sidebar-primary))]' : ''} />
                  <span className="flex-1">{label}</span>
                  {key === 'workspace' && <span className="size-1.5 rounded-full bg-[hsl(var(--sidebar-primary))] pulse-dot" />}
                </button>
              ))}
            </nav>
          </div>

          <div className="mt-auto rounded-2xl border border-[hsl(var(--sidebar-border))] bg-[hsl(var(--sidebar-accent)/.62)] p-4">
            <div className="mb-3 flex items-center gap-2 text-[hsl(var(--sidebar-primary))]"><ShieldCheck size={16} /><span className="mono-font text-[10px] uppercase tracking-[.12em]">Private by design</span></div>
            <p className="text-[12px] leading-5 text-[hsl(var(--sidebar-foreground)/.62)]">Your thinking stays yours. Suggestions are always low-risk and always ask first.</p>
          </div>
          <div className="mt-4 flex items-center gap-3 px-2">
            <div className="grid size-8 place-items-center rounded-full bg-[hsl(var(--sidebar-primary)/.18)] text-xs font-bold text-[hsl(var(--sidebar-primary))]">AM</div>
            <div><p className="text-xs font-semibold">Alex Morgan</p><p className="mono-font text-[9px] text-[hsl(var(--sidebar-foreground)/.42)]">Personal space</p></div>
            <button className="ml-auto text-[hsl(var(--sidebar-foreground)/.45)]" onClick={() => setToast('Settings are intentionally quiet for now.')} data-testid="button-settings"><CircleHelp size={16} /></button>
          </div>
        </div>
      </aside>
      {mobileNav && <button className="fixed inset-0 z-30 bg-[hsl(var(--foreground)/.25)] md:hidden" onClick={() => setMobileNav(false)} aria-label="Close menu" data-testid="button-nav-overlay" />}

      <main className="min-w-0 flex-1">
        <header className="flex h-[76px] items-center justify-between border-b border-[hsl(var(--border)/.7)] px-5 sm:px-8 lg:px-12">
          <div className="flex items-center gap-3">
            <button className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card)/.6)] p-2.5 md:hidden" onClick={() => setMobileNav(true)} data-testid="button-open-nav"><Menu size={18} /></button>
            <div><p className="mono-font text-[10px] uppercase tracking-[.16em] text-[hsl(var(--muted-foreground))]">Tuesday, April 22, 2025</p><p className="mt-0.5 text-sm font-semibold">{navLabel}</p></div>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden items-center gap-2 rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card)/.55)] px-3 py-2 text-xs text-[hsl(var(--muted-foreground))] sm:flex"><Search size={14} /><span>Search your thinking</span><span className="mono-font ml-5 text-[10px]">⌘ K</span></div>
            <button className="relative rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card)/.55)] p-2.5 text-[hsl(var(--muted-foreground))] transition hover:text-[hsl(var(--foreground))]" onClick={() => setToast('You are all caught up.')} data-testid="button-notifications"><Bell size={17} /><span className="absolute right-2 top-2 size-1.5 rounded-full bg-[hsl(var(--accent))]" /></button>
          </div>
        </header>
        <div className="mx-auto max-w-[1390px] px-5 py-8 sm:px-8 lg:px-12 lg:py-10">
          {activeNav === 'workspace' && <Workspace active={active} updateActive={updateActive} onNavigate={setActiveNav} onOutcome={selectOutcome} />}
          {activeNav === 'new' && <NewDecision onCreate={addDecision} onCancel={() => setActiveNav('workspace')} />}
          {activeNav === 'history' && <HistoryView records={records} onSelect={(record) => { setRecords((current) => [record, ...current.filter((item) => item.id !== record.id)]); setActiveNav('workspace'); }} />}
          {activeNav === 'regret' && <RegretView records={records} />}
          {activeNav === 'patterns' && <PatternsView records={records} />}
          {activeNav === 'suggestions' && <SuggestionsView onOpen={() => setModal('suggestion')} />}
        </div>
      </main>

      {modal === 'suggestion' && <ConfirmModal onClose={() => setModal(null)} onConfirm={() => { setModal(null); setToast('Saved to your next-step list. Nothing was sent or changed.'); }} />}
      {toast && <div className="fixed bottom-5 left-1/2 z-[60] flex -translate-x-1/2 items-center gap-3 rounded-2xl bg-[hsl(var(--sidebar))] px-4 py-3 text-xs font-semibold text-[hsl(var(--sidebar-foreground))] shadow-2xl fade-up" role="status" data-testid="status-toast"><span className="grid size-5 place-items-center rounded-full bg-[hsl(var(--sidebar-primary))] text-[hsl(var(--sidebar-primary-foreground))]"><Check size={13} /></span>{toast}</div>}
    </div>
  );
}

function PageIntro({ eyebrow, title, body, action }: { eyebrow: string; title: string; body: string; action?: ReactNode }) {
  return <div className="mb-8 flex flex-col justify-between gap-5 sm:flex-row sm:items-end"><div className="fade-up"><p className="mono-font mb-3 text-[10px] font-medium uppercase tracking-[.2em] text-[hsl(var(--primary))]">{eyebrow}</p><h1 className="display-font max-w-[670px] text-[clamp(30px,4vw,47px)] font-bold leading-[1.03] tracking-[-.055em]">{title}</h1><p className="mt-3 max-w-xl text-[14px] leading-6 text-[hsl(var(--muted-foreground))]">{body}</p></div>{action}</div>;
}

function Workspace({ active, updateActive, onNavigate, onOutcome }: { active: DecisionRecord; updateActive: (patch: Partial<DecisionRecord>) => void; onNavigate: (key: NavKey) => void; onOutcome: (outcome: Outcome) => void }) {
  return <section>
    <PageIntro eyebrow="The signal in the noise" title="You do not need more certainty. You need a next step." body="A private room to put the messy thing down, look at it from six angles, and choose with your eyes open." action={<button onClick={() => onNavigate('new')} className="group flex items-center gap-2 rounded-xl bg-[hsl(var(--primary))] px-4 py-3 text-xs font-bold text-[hsl(var(--primary-foreground))] shadow-lg shadow-[hsl(var(--primary)/.18)] transition hover:-translate-y-0.5" data-testid="button-start-new"><Plus size={16} /> Start a new decision <ArrowRight size={15} className="transition group-hover:translate-x-0.5" /></button>} />
    <div className="grid gap-6 xl:grid-cols-[minmax(0,1.42fr)_minmax(300px,.72fr)]">
      <div className="space-y-6">
        <DecisionHeader active={active} />
        <div className="rounded-[24px] border border-[hsl(var(--border))] bg-[hsl(var(--card)/.72)] p-5 shadow-[var(--shadow-soft)] sm:p-7">
          <div className="mb-6 flex items-center justify-between"><div><p className="mono-font text-[10px] uppercase tracking-[.16em] text-[hsl(var(--muted-foreground))]">Multi-agent synthesis</p><h2 className="display-font mt-1 text-xl font-bold tracking-[-.03em]">Here is what I see</h2></div><div className="flex items-center gap-2 rounded-full bg-[hsl(var(--secondary)/.55)] px-3 py-1.5 text-[10px] font-semibold text-[hsl(var(--secondary-foreground))]"><span className="size-1.5 rounded-full bg-[hsl(var(--chart-2))] pulse-dot" /> Six perspectives aligned</div></div>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{agentData.map((agent) => <AgentCard key={agent.name} agent={agent} />)}</div>
        </div>
        <Recommendation active={active} updateActive={updateActive} onOutcome={onOutcome} />
      </div>
      <aside className="space-y-6">
        <SignalCard active={active} />
        <CheckInCard active={active} onNavigate={onNavigate} />
      </aside>
    </div>
  </section>;
}

function DecisionHeader({ active }: { active: DecisionRecord }) {
  return <div className="rounded-[24px] bg-[hsl(var(--sidebar))] p-6 text-[hsl(var(--sidebar-foreground))] shadow-[var(--shadow-soft)] sm:p-8"><div className="mb-8 flex items-start justify-between gap-4"><div><div className="mb-3 flex items-center gap-2"><span className="mono-font rounded-full border border-[hsl(var(--sidebar-primary)/.35)] bg-[hsl(var(--sidebar-primary)/.12)] px-2.5 py-1 text-[9px] uppercase tracking-[.16em] text-[hsl(var(--sidebar-primary))]">Active thread</span><span className="mono-font text-[10px] text-[hsl(var(--sidebar-foreground)/.4)]">{active.createdAt}</span></div><h2 className="display-font max-w-2xl text-[clamp(24px,3.5vw,38px)] font-bold leading-[1.08] tracking-[-.05em]">{active.title}</h2></div><div className="hidden size-12 shrink-0 place-items-center rounded-2xl border border-[hsl(var(--sidebar-border))] text-[hsl(var(--sidebar-primary))] sm:grid"><Brain size={23} /></div></div><div className="border-l-2 border-[hsl(var(--sidebar-primary)/.65)] pl-4"><p className="mono-font mb-2 text-[9px] uppercase tracking-[.16em] text-[hsl(var(--sidebar-foreground)/.42)]">What matters</p><p className="max-w-2xl text-[13px] leading-6 text-[hsl(var(--sidebar-foreground)/.72)]">{active.context}</p></div></div>;
}

function AgentCard({ agent }: { agent: typeof agentData[number] }) {
  const Icon = agent.icon;
  const colorMap: Record<string, string> = { lavender: 'bg-[hsl(252_68%_58%/.1)] text-[hsl(252_68%_58%)]', peach: 'bg-[hsl(22_82%_67%/.16)] text-[hsl(22_72%_46%)]', mint: 'bg-[hsl(168_45%_42%/.13)] text-[hsl(168_45%_35%)]', butter: 'bg-[hsl(45_76%_59%/.18)] text-[hsl(38_75%_38%)]', rose: 'bg-[hsl(4_63%_55%/.12)] text-[hsl(4_63%_45%)]', indigo: 'bg-[hsl(252_34%_18%)] text-[hsl(22_82%_67%)]' };
  return <article className="lift rounded-2xl border border-[hsl(var(--border)/.8)] bg-[hsl(var(--background)/.62)] p-4" data-testid={`card-agent-${agent.name.toLowerCase().replaceAll(' ', '-')}`}><div className="mb-4 flex items-start justify-between gap-2"><span className={`grid size-8 place-items-center rounded-xl ${colorMap[agent.color]}`}><Icon size={15} /></span><span className="mono-font text-[9px] text-[hsl(var(--muted-foreground)/.7)]">01 / 06</span></div><p className="text-[11px] font-bold">{agent.name}</p><p className="mt-1 text-[11px] font-semibold leading-4 text-[hsl(var(--foreground)/.72)]">{agent.summary}</p><p className="mt-3 text-[11px] leading-5 text-[hsl(var(--muted-foreground))]">{agent.text}</p></article>;
}

function Recommendation({ active, updateActive, onOutcome }: { active: DecisionRecord; updateActive: (patch: Partial<DecisionRecord>) => void; onOutcome: (outcome: Outcome) => void }) {
  const selected = active.selected;
  return <section className="relative overflow-hidden rounded-[24px] border border-[hsl(var(--primary)/.35)] bg-[hsl(var(--primary)/.07)] p-5 sm:p-7" data-testid="section-recommendation"><div className="absolute -right-12 -top-16 size-44 rounded-full border-[24px] border-[hsl(var(--accent)/.18)]" /><div className="relative"><div className="flex items-start justify-between gap-4"><div><div className="mb-3 flex items-center gap-2 text-[hsl(var(--primary))]"><Sparkles size={16} /><span className="mono-font text-[10px] font-medium uppercase tracking-[.18em]">Decision agent</span></div><h2 className="display-font text-2xl font-bold tracking-[-.045em]">My read: {active.options[active.recommendation]}</h2><p className="mt-3 max-w-2xl text-[13px] leading-6 text-[hsl(var(--muted-foreground))]">Choose the path that gives you more information, agency, and room to become the person who can handle the next version of this problem.</p></div><div className="hidden size-14 place-items-center rounded-2xl bg-[hsl(var(--accent)/.3)] text-[hsl(var(--accent-foreground))] sm:grid"><Lightbulb size={25} /></div></div><div className="mt-6 grid gap-2 sm:grid-cols-2">{active.options.map((option, index) => <button key={option} onClick={() => updateActive({ selected: index })} className={`flex items-center justify-between rounded-xl border px-4 py-3 text-left text-xs font-semibold transition ${selected === index ? 'border-[hsl(var(--primary))] bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))] shadow-md' : 'border-[hsl(var(--border))] bg-[hsl(var(--card)/.72)] hover:border-[hsl(var(--primary)/.5)]'}`} data-testid={`button-select-option-${index}`}><span>{option}</span>{selected === index ? <Check size={16} /> : <ChevronRight size={15} className="text-[hsl(var(--muted-foreground))]" />}</button>)}</div>{selected !== undefined && <div className="mt-6 border-t border-[hsl(var(--primary)/.17)] pt-5 fade-up"><div className="flex flex-wrap items-center justify-between gap-3"><p className="text-xs font-semibold">Did this recommendation earn your trust?</p><div className="flex gap-2"><button onClick={() => updateActive({ accepted: true })} className={`rounded-xl px-3 py-2 text-[11px] font-bold transition ${active.accepted === true ? 'bg-[hsl(var(--chart-2))] text-white' : 'bg-[hsl(var(--card))] hover:bg-[hsl(var(--secondary))]'}`} data-testid="button-accept-recommendation"><ThumbsUp size={14} className="mr-1.5 inline" /> I’ll take it</button><button onClick={() => updateActive({ accepted: false })} className={`rounded-xl px-3 py-2 text-[11px] font-bold transition ${active.accepted === false ? 'bg-[hsl(var(--foreground))] text-[hsl(var(--background))]' : 'bg-[hsl(var(--card))] hover:bg-[hsl(var(--muted))]'}`} data-testid="button-decline-recommendation"><ThumbsDown size={14} className="mr-1.5 inline" /> Not this time</button></div></div>{active.accepted !== undefined && <div className="mt-5 flex flex-col gap-3 rounded-xl bg-[hsl(var(--card)/.8)] p-4 sm:flex-row sm:items-center sm:justify-between"><div><p className="text-xs font-bold">When you know how it went, come back here.</p><p className="mt-1 text-[11px] text-[hsl(var(--muted-foreground))]">A good outcome is not always the same as an easy outcome.</p></div><div className="flex gap-1.5"><OutcomeButton kind="good" current={active.outcome} onClick={() => onOutcome('good')} /><OutcomeButton kind="neutral" current={active.outcome} onClick={() => onOutcome('neutral')} /><OutcomeButton kind="bad" current={active.outcome} onClick={() => onOutcome('bad')} /></div></div>}</div>}</div></section>;
}

function OutcomeButton({ kind, current, onClick }: { kind: Outcome; current?: Outcome; onClick: () => void }) {
  const labels = { good: 'Good', neutral: 'Okay', bad: 'Bad' };
  const icons = { good: ThumbsUp, neutral: Scale, bad: ThumbsDown };
  const Icon = icons[kind];
  return <button onClick={onClick} className={`rounded-lg px-2.5 py-2 text-[10px] font-bold transition ${current === kind ? 'bg-[hsl(var(--secondary-foreground))] text-[hsl(var(--secondary))]' : 'bg-[hsl(var(--muted)/.8)] hover:bg-[hsl(var(--secondary))]'}`} data-testid={`button-outcome-${kind}`}><Icon size={12} className="mr-1 inline" />{labels[kind]}</button>;
}

function SignalCard({ active }: { active: DecisionRecord }) {
  return <div className="rounded-[22px] border border-[hsl(var(--border))] bg-[hsl(var(--card)/.68)] p-5 sm:p-6"><div className="mb-5 flex items-center justify-between"><p className="mono-font text-[10px] uppercase tracking-[.17em] text-[hsl(var(--muted-foreground))]">Clarity signal</p><span className="rounded-full bg-[hsl(var(--secondary))] px-2.5 py-1 text-[10px] font-bold text-[hsl(var(--secondary-foreground))]">82 / 100</span></div><div className="mb-4 h-2 overflow-hidden rounded-full bg-[hsl(var(--muted))]"><div className="bar-fill h-full w-[82%] rounded-full bg-[hsl(var(--chart-2))]" /></div><p className="text-[13px] font-bold">You have enough to move.</p><p className="mt-2 text-[11px] leading-5 text-[hsl(var(--muted-foreground))]">The remaining uncertainty is information you can only get by taking the next step.</p><div className="mt-5 flex items-center gap-2 text-[10px] font-semibold text-[hsl(var(--muted-foreground))]"><span className="size-2 rounded-full bg-[hsl(var(--chart-2))]" /> Based on your values and {active.options.length} paths</div></div>;
}

function CheckInCard({ active, onNavigate }: { active: DecisionRecord; onNavigate: (key: NavKey) => void }) {
  return <div className="rounded-[22px] bg-[hsl(var(--accent)/.24)] p-5 sm:p-6"><div className="mb-4 flex size-9 items-center justify-center rounded-xl bg-[hsl(var(--accent))]"><Bell size={17} /></div><p className="display-font text-lg font-bold tracking-[-.03em]">A small check-in, later</p><p className="mt-2 text-[12px] leading-5 text-[hsl(var(--foreground)/.65)]">Decisions become wisdom when you close the loop. We’ll ask how this one felt in a little while.</p><button onClick={() => onNavigate('history')} className="mt-5 flex items-center gap-1.5 text-[11px] font-bold text-[hsl(var(--foreground))] hover:gap-2.5 transition-all" data-testid="button-view-history">See your decision trail <ArrowRight size={14} /></button></div>;
}

function NewDecision({ onCreate, onCancel }: { onCreate: (title: string, context: string, options: string[]) => void; onCancel: () => void }) {
  const [title, setTitle] = useState('');
  const [context, setContext] = useState('');
  const [first, setFirst] = useState('');
  const [second, setSecond] = useState('');
  const canSubmit = title.trim() && context.trim() && first.trim() && second.trim();
  return <section className="mx-auto max-w-4xl"><PageIntro eyebrow="Make it concrete" title="Put the decision down. We’ll help you hold it." body="You do not need to explain it perfectly. Start with what is true, what is pulling at you, and the paths you can actually take." action={<button onClick={onCancel} className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card)/.6)] px-4 py-3 text-xs font-bold transition hover:bg-[hsl(var(--muted))]" data-testid="button-cancel-new">Back to workspace</button>} /><div className="rounded-[26px] border border-[hsl(var(--border))] bg-[hsl(var(--card)/.72)] p-5 shadow-[var(--shadow-soft)] sm:p-8"><div className="mb-8 flex items-center gap-3"><span className="grid size-10 place-items-center rounded-xl bg-[hsl(var(--primary)/.12)] text-[hsl(var(--primary))]"><Sparkles size={19} /></span><div><p className="text-sm font-bold">A clean slate</p><p className="text-[11px] text-[hsl(var(--muted-foreground))]">Private, imperfect, enough.</p></div></div><label className="mb-2 block text-xs font-bold" htmlFor="decision-title">What are you deciding?</label><input id="decision-title" value={title} onChange={(event) => setTitle(event.target.value)} placeholder="Should I…?" className="mb-6 w-full rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--background)/.7)] px-4 py-3.5 text-sm outline-none transition placeholder:text-[hsl(var(--muted-foreground)/.6)] focus:border-[hsl(var(--primary))] focus:ring-4 focus:ring-[hsl(var(--primary)/.1)]" data-testid="input-decision-title" /><label className="mb-2 block text-xs font-bold" htmlFor="decision-context">What is making it noisy?</label><textarea id="decision-context" value={context} onChange={(event) => setContext(event.target.value)} placeholder="Include the facts, the feeling, or the part you keep circling…" rows={5} className="mb-6 w-full resize-none rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--background)/.7)] px-4 py-3.5 text-sm leading-6 outline-none transition placeholder:text-[hsl(var(--muted-foreground)/.6)] focus:border-[hsl(var(--primary))] focus:ring-4 focus:ring-[hsl(var(--primary)/.1)]" data-testid="input-decision-context" /><div className="mb-2 flex items-center justify-between"><label className="block text-xs font-bold">What are the real options?</label><span className="mono-font text-[9px] uppercase tracking-widest text-[hsl(var(--muted-foreground))]">Two is enough</span></div><div className="grid gap-3 sm:grid-cols-2"><input value={first} onChange={(event) => setFirst(event.target.value)} placeholder="Option one" className="w-full rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--background)/.7)] px-4 py-3 text-sm outline-none focus:border-[hsl(var(--primary))]" data-testid="input-option-one" /><input value={second} onChange={(event) => setSecond(event.target.value)} placeholder="Option two" className="w-full rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--background)/.7)] px-4 py-3 text-sm outline-none focus:border-[hsl(var(--primary))]" data-testid="input-option-two" /></div><div className="mt-8 flex flex-col-reverse justify-end gap-3 border-t border-[hsl(var(--border))] pt-6 sm:flex-row"><button onClick={onCancel} className="rounded-xl px-5 py-3 text-xs font-bold text-[hsl(var(--muted-foreground))] hover:bg-[hsl(var(--muted))]" data-testid="button-dismiss-new">Not yet</button><button disabled={!canSubmit} onClick={() => onCreate(title.trim(), context.trim(), [first.trim(), second.trim()])} className="flex items-center justify-center gap-2 rounded-xl bg-[hsl(var(--primary))] px-5 py-3 text-xs font-bold text-[hsl(var(--primary-foreground))] shadow-lg shadow-[hsl(var(--primary)/.15)] transition hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-40" data-testid="button-submit-decision"><Sparkles size={15} /> Think this through</button></div></div></section>;
}

function HistoryView({ records, onSelect }: { records: DecisionRecord[]; onSelect: (record: DecisionRecord) => void }) {
  const completed = records.filter((record) => record.accepted !== undefined);
  return <section><PageIntro eyebrow="Your trail, not a scorecard" title="Look back without rewriting the story." body="Every choice leaves a little signal behind. Notice what helped, what surprised you, and what you already know how to do." /><div className="grid gap-5 lg:grid-cols-[1fr_310px]"><div className="space-y-3">{records.map((record, index) => <button key={record.id} onClick={() => onSelect(record)} className={`lift flex w-full items-center gap-4 rounded-2xl border p-4 text-left transition sm:p-5 ${index === 0 ? 'border-[hsl(var(--primary)/.32)] bg-[hsl(var(--primary)/.06)]' : 'border-[hsl(var(--border))] bg-[hsl(var(--card)/.66)]'}`} data-testid={`button-history-${record.id}`}><div className={`grid size-11 shrink-0 place-items-center rounded-2xl ${index === 0 ? 'bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]' : 'bg-[hsl(var(--muted))] text-[hsl(var(--muted-foreground))]'}`}><Brain size={19} /></div><div className="min-w-0 flex-1"><div className="mb-1 flex flex-wrap items-center gap-2"><span className="mono-font text-[9px] uppercase tracking-[.14em] text-[hsl(var(--muted-foreground))]">{record.createdAt}</span>{index === 0 && <span className="rounded-full bg-[hsl(var(--primary)/.13)] px-2 py-0.5 text-[9px] font-bold text-[hsl(var(--primary))]">Current</span>}</div><p className="truncate text-[13px] font-bold">{record.title}</p><p className="mt-1 truncate text-[11px] text-[hsl(var(--muted-foreground))]">{record.selected !== undefined ? `Chose: ${record.options[record.selected]}` : 'Still thinking this through'}</p></div><HistoryOutcome outcome={record.outcome} /><ChevronRight size={16} className="shrink-0 text-[hsl(var(--muted-foreground))]" /></button>)}</div><div className="rounded-[22px] border border-[hsl(var(--border))] bg-[hsl(var(--card)/.66)] p-5 sm:p-6"><p className="mono-font text-[10px] uppercase tracking-[.17em] text-[hsl(var(--muted-foreground))]">A gentle count</p><p className="display-font mt-4 text-5xl font-bold tracking-[-.07em]">{completed.length}</p><p className="mt-1 text-sm font-bold">decisions closed</p><p className="mt-3 text-[11px] leading-5 text-[hsl(var(--muted-foreground))]">Not every decision needs to feel easy to be a good decision. Closing the loop is the win.</p><div className="mt-6 hairline" /><div className="mt-5 flex justify-between text-[11px]"><span className="text-[hsl(var(--muted-foreground))]">Good outcomes</span><strong>{completed.filter((item) => item.outcome === 'good').length}</strong></div><div className="mt-3 flex justify-between text-[11px]"><span className="text-[hsl(var(--muted-foreground))]">Trusting your read</span><strong>{completed.filter((item) => item.accepted).length}</strong></div></div></div></section>;
}

function HistoryOutcome({ outcome }: { outcome?: Outcome }) {
  if (!outcome) return <span className="hidden rounded-full bg-[hsl(var(--muted))] px-2 py-1 text-[9px] font-bold text-[hsl(var(--muted-foreground))] sm:block">Open</span>;
  const copy = { good: 'Good', neutral: 'Okay', bad: 'Hard' };
  return <span className={`hidden rounded-full px-2 py-1 text-[9px] font-bold sm:block ${outcome === 'good' ? 'bg-[hsl(var(--secondary))] text-[hsl(var(--secondary-foreground))]' : outcome === 'bad' ? 'bg-[hsl(var(--destructive)/.1)] text-[hsl(var(--destructive))]' : 'bg-[hsl(var(--accent)/.24)] text-[hsl(var(--accent-foreground))]'}`}>{copy[outcome]}</span>;
}

function RegretView({ records }: { records: DecisionRecord[] }) {
  const good = records.filter((record) => record.outcome === 'good').length;
  return <section><PageIntro eyebrow="Regret, made useful" title="The point is not to never regret. It is to learn what regret is telling you." body="Track the emotional aftertaste of your choices. Patterns become easier to see when they are outside your head." /><div className="grid gap-5 lg:grid-cols-[1.25fr_.75fr]"><div className="rounded-[24px] border border-[hsl(var(--border))] bg-[hsl(var(--card)/.7)] p-5 sm:p-7"><div className="mb-8 flex items-start justify-between"><div><p className="mono-font text-[10px] uppercase tracking-[.16em] text-[hsl(var(--muted-foreground))]">Outcome pulse</p><h2 className="display-font mt-1 text-2xl font-bold tracking-[-.04em]">Your choices, over time</h2></div><TrendingUp className="text-[hsl(var(--chart-2))]" size={22} /></div><div className="flex h-52 items-end gap-3 border-b border-l border-[hsl(var(--border))] px-3 pb-0 pt-4 sm:gap-6"><div className="flex h-full flex-1 flex-col justify-end gap-2"><div className="bar-fill h-[54%] rounded-t-xl bg-[hsl(var(--primary)/.7)]" /><span className="mono-font -mb-6 text-center text-[9px] text-[hsl(var(--muted-foreground))]">FEB</span></div><div className="flex h-full flex-1 flex-col justify-end gap-2"><div className="bar-fill h-[72%] rounded-t-xl bg-[hsl(var(--chart-2)/.75)]" /><span className="mono-font -mb-6 text-center text-[9px] text-[hsl(var(--muted-foreground))]">MAR</span></div><div className="flex h-full flex-1 flex-col justify-end gap-2"><div className="bar-fill h-[88%] rounded-t-xl bg-[hsl(var(--accent))]" /><span className="mono-font -mb-6 text-center text-[9px] text-[hsl(var(--muted-foreground))]">APR</span></div></div><div className="mt-12 flex flex-wrap gap-4 text-[10px] font-semibold text-[hsl(var(--muted-foreground))]"><span><i className="mr-1.5 inline-block size-2 rounded-full bg-[hsl(var(--primary))]" />Confidence</span><span><i className="mr-1.5 inline-block size-2 rounded-full bg-[hsl(var(--chart-2))]" />Ease after</span><span><i className="mr-1.5 inline-block size-2 rounded-full bg-[hsl(var(--accent))]" />Learning</span></div></div><div className="space-y-5"><div className="rounded-[24px] bg-[hsl(var(--sidebar))] p-6 text-[hsl(var(--sidebar-foreground))]"><p className="mono-font text-[10px] uppercase tracking-[.16em] text-[hsl(var(--sidebar-foreground)/.45)]">So far</p><p className="display-font mt-4 text-5xl font-bold tracking-[-.08em]">{good}<span className="ml-1 text-2xl text-[hsl(var(--sidebar-primary))]">/ {records.length}</span></p><p className="mt-2 text-xs font-semibold">choices that feel good in hindsight</p><p className="mt-5 border-t border-[hsl(var(--sidebar-border))] pt-4 text-[11px] leading-5 text-[hsl(var(--sidebar-foreground)/.62)]">A “bad” outcome is not a bad decision. We are tracking the gap between the two.</p></div><div className="rounded-[24px] border border-[hsl(var(--border))] bg-[hsl(var(--accent)/.16)] p-6"><p className="text-xs font-bold">One useful question</p><p className="mt-2 text-[13px] leading-6">What did you know then that you know more clearly now?</p><button className="mt-4 text-[11px] font-bold underline decoration-[hsl(var(--accent))] underline-offset-4" onClick={() => window.alert('Your answer will be part of your private decision journal.')} data-testid="button-reflection-question">Write a reflection</button></div></div></div></section>;
}

function PatternsView({ records }: { records: DecisionRecord[] }) {
  const stats = useMemo(() => ({ accepted: records.filter((r) => r.accepted).length, good: records.filter((r) => r.outcome === 'good').length, total: records.length }), [records]);
  return <section><PageIntro eyebrow="The shape of your thinking" title="You are more consistent than you think." body="A few signals from the decisions you have logged. These are prompts, not personality tests." /><div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3"><PatternCard icon={Target} label="You choose agency" value={`${stats.accepted} of ${stats.total}`} body="When a recommendation feels like yours, you tend to act on it." accent="lavender" /><PatternCard icon={TrendingUp} label="Your hindsight is kind" value={`${stats.good} good`} body="You give yourself room to call an outcome useful, even when it was not easy." accent="mint" /><PatternCard icon={Scale} label="You weigh both sides" value="Balanced" body="You rarely rush to the shiny option. Your best calls pair ambition with a practical guardrail." accent="peach" /></div><div className="mt-5 grid gap-5 lg:grid-cols-[.8fr_1.2fr]"><div className="rounded-[24px] border border-[hsl(var(--border))] bg-[hsl(var(--card)/.7)] p-6"><p className="mono-font text-[10px] uppercase tracking-[.16em] text-[hsl(var(--muted-foreground))]">Values in the room</p><div className="mt-6 space-y-5"><ValueBar label="Freedom" percent={78} color="bg-[hsl(var(--primary))]" /><ValueBar label="Learning" percent={71} color="bg-[hsl(var(--accent))]" /><ValueBar label="Stability" percent={56} color="bg-[hsl(var(--chart-2))]" /></div></div><div className="rounded-[24px] border border-[hsl(var(--border))] bg-[hsl(var(--primary)/.07)] p-6 sm:p-7"><div className="flex items-start gap-4"><span className="grid size-10 shrink-0 place-items-center rounded-xl bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]"><Sparkles size={18} /></span><div><p className="mono-font text-[10px] uppercase tracking-[.16em] text-[hsl(var(--primary))]">A pattern worth keeping</p><h2 className="display-font mt-2 text-2xl font-bold tracking-[-.04em]">You do not need permission to choose the braver option.</h2><p className="mt-3 max-w-xl text-[13px] leading-6 text-[hsl(var(--muted-foreground))]">You seem to move best when you name the risk plainly, then stop treating the existence of risk as a reason to stay still.</p></div></div></div></div></section>;
}

function PatternCard({ icon: Icon, label, value, body, accent }: { icon: typeof Target; label: string; value: string; body: string; accent: string }) {
  const backgrounds: Record<string, string> = { lavender: 'bg-[hsl(var(--primary)/.1)] text-[hsl(var(--primary))]', mint: 'bg-[hsl(var(--secondary))] text-[hsl(var(--secondary-foreground))]', peach: 'bg-[hsl(var(--accent)/.22)] text-[hsl(var(--accent-foreground))]' };
  return <div className="lift rounded-[22px] border border-[hsl(var(--border))] bg-[hsl(var(--card)/.7)] p-6"><span className={`grid size-10 place-items-center rounded-xl ${backgrounds[accent]}`}><Icon size={18} /></span><p className="mt-6 text-xs font-bold text-[hsl(var(--muted-foreground))]">{label}</p><p className="display-font mt-1 text-3xl font-bold tracking-[-.06em]">{value}</p><p className="mt-3 text-[12px] leading-5 text-[hsl(var(--muted-foreground))]">{body}</p></div>;
}

function ValueBar({ label, percent, color }: { label: string; percent: number; color: string }) {
  return <div><div className="mb-2 flex justify-between text-xs font-bold"><span>{label}</span><span className="mono-font text-[10px] text-[hsl(var(--muted-foreground))]">{percent}%</span></div><div className="h-2 overflow-hidden rounded-full bg-[hsl(var(--muted))]"><div className={`bar-fill h-full rounded-full ${color}`} style={{ width: `${percent}%` }} /></div></div>;
}

function SuggestionsView({ onOpen }: { onOpen: () => void }) {
  return <section><PageIntro eyebrow="Helpful, never pushy" title="A few low-risk next steps, if you want them." body="DecisionOS can notice small actions that reduce friction. It never sends, buys, accepts, or changes anything without your confirmation." /><div className="mb-5 flex items-center gap-2 rounded-2xl border border-[hsl(var(--secondary-foreground)/.16)] bg-[hsl(var(--secondary)/.45)] px-4 py-3 text-[11px] font-semibold text-[hsl(var(--secondary-foreground))]"><ShieldCheck size={16} /><span>Safety boundary active:</span><span className="font-normal opacity-75">only reversible, low-stakes actions appear here.</span></div><div className="grid gap-4 lg:grid-cols-2"><SuggestionCard icon={Search} title="Gather the studio’s runway details" detail="Draft three questions for the studio before your follow-up call." tag="Low effort · reversible" onOpen={onOpen} /><SuggestionCard icon={Target} title="Write your decision guardrail" detail="Capture the one condition that makes the braver option feel responsible." tag="5 minutes · private" onOpen={onOpen} /><SuggestionCard icon={Bell} title="Set a gentle check-in" detail="Remind yourself to revisit this choice after your first month." tag="Low stakes · later" onOpen={onOpen} /></div><div className="mt-6 rounded-[24px] border border-dashed border-[hsl(var(--border))] p-6 text-center"><p className="text-xs font-bold">Something consequential?</p><p className="mx-auto mt-2 max-w-md text-[11px] leading-5 text-[hsl(var(--muted-foreground))]">That belongs in your hands. DecisionOS can help you think, but it will always pause before anything that affects money, people, or commitments.</p></div></section>;
}

function SuggestionCard({ icon: Icon, title, detail, tag, onOpen }: { icon: typeof Search; title: string; detail: string; tag: string; onOpen: () => void }) {
  return <article className="lift flex flex-col justify-between rounded-[22px] border border-[hsl(var(--border))] bg-[hsl(var(--card)/.7)] p-5 sm:p-6"><div><div className="mb-5 flex items-start justify-between"><span className="grid size-10 place-items-center rounded-xl bg-[hsl(var(--accent)/.22)] text-[hsl(var(--accent-foreground))]"><Icon size={18} /></span><span className="mono-font rounded-full bg-[hsl(var(--muted))] px-2.5 py-1 text-[9px] uppercase tracking-[.1em] text-[hsl(var(--muted-foreground))]">{tag}</span></div><h2 className="display-font text-xl font-bold tracking-[-.04em]">{title}</h2><p className="mt-2 text-[12px] leading-5 text-[hsl(var(--muted-foreground))]">{detail}</p></div><button onClick={onOpen} className="mt-7 flex w-fit items-center gap-2 rounded-xl bg-[hsl(var(--foreground))] px-4 py-2.5 text-[11px] font-bold text-[hsl(var(--background))] transition hover:-translate-y-0.5" data-testid={`button-open-suggestion-${title.toLowerCase().replaceAll(' ', '-')}`}><Lightbulb size={14} /> See the next step <ArrowRight size={14} /></button></article>;
}

function ConfirmModal({ onClose, onConfirm }: { onClose: () => void; onConfirm: () => void }) {
  return <div className="fixed inset-0 z-50 grid place-items-center bg-[hsl(var(--foreground)/.38)] p-5 backdrop-blur-sm"><div className="w-full max-w-md rounded-[26px] border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-6 shadow-2xl sm:p-8 fade-up" role="dialog" aria-modal="true" aria-labelledby="confirm-title"><div className="flex items-start justify-between"><span className="grid size-11 place-items-center rounded-2xl bg-[hsl(var(--accent)/.24)] text-[hsl(var(--accent-foreground))]"><ShieldCheck size={21} /></span><button onClick={onClose} className="rounded-lg p-2 text-[hsl(var(--muted-foreground))] hover:bg-[hsl(var(--muted))]" data-testid="button-close-confirm"><X size={18} /></button></div><p className="mono-font mt-6 text-[10px] uppercase tracking-[.17em] text-[hsl(var(--primary))]">Your call, always</p><h2 id="confirm-title" className="display-font mt-2 text-2xl font-bold tracking-[-.045em]">Ready to add this to your next steps?</h2><p className="mt-3 text-[13px] leading-6 text-[hsl(var(--muted-foreground))]">This only saves a private note for you. Nothing will be sent, accepted, purchased, or changed outside DecisionOS.</p><div className="mt-7 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end"><button onClick={onClose} className="rounded-xl px-4 py-3 text-xs font-bold text-[hsl(var(--muted-foreground))] hover:bg-[hsl(var(--muted))]" data-testid="button-cancel-confirm">Not yet</button><button onClick={onConfirm} className="rounded-xl bg-[hsl(var(--primary))] px-4 py-3 text-xs font-bold text-[hsl(var(--primary-foreground))] shadow-lg shadow-[hsl(var(--primary)/.16)]" data-testid="button-confirm-suggestion">Yes, save it</button></div></div></div>;
}

function AuthLanding() {
  const [, setLocation] = useLocation();

  return (
    <main className="auth-shell auth-grid min-h-[100dvh] overflow-hidden">
      <div className="mx-auto grid min-h-[100dvh] max-w-[1440px] items-center gap-12 px-5 py-8 sm:px-10 lg:grid-cols-[1.08fr_.92fr] lg:px-16 lg:py-12">
        <section className="relative z-10 max-w-2xl">
          <div className="mb-10 flex items-center gap-3 fade-up">
            <img src={`${basePath}/logo.svg`} alt="" className="size-11 rounded-[14px] shadow-lg shadow-[#29213E]/10" />
            <div>
              <p className="display-font text-[17px] font-bold tracking-[-.04em]">DecisionOS</p>
              <p className="mono-font text-[9px] uppercase tracking-[.18em] text-[hsl(var(--muted-foreground))]">Think clearer</p>
            </div>
          </div>
          <p className="mono-font text-[10px] uppercase tracking-[.22em] text-[hsl(var(--primary))] fade-up">A private room for the messy things</p>
          <h1 className="display-font mt-5 max-w-[650px] text-[clamp(42px,6vw,78px)] font-bold leading-[.98] tracking-[-.075em] text-[hsl(var(--foreground))] fade-up fade-up-delay-1">
            You do not need more certainty. You need a next step.
          </h1>
          <p className="mt-7 max-w-xl text-[15px] leading-7 text-[hsl(var(--muted-foreground))] fade-up fade-up-delay-2">
            DecisionOS brings six useful perspectives to the choices you keep circling, then learns what good decisions look like for you.
          </p>
          <div className="mt-9 flex flex-col gap-3 sm:flex-row fade-up fade-up-delay-3">
            <button onClick={() => setLocation('/sign-in')} className="group flex items-center justify-center gap-2 rounded-xl bg-[hsl(var(--primary))] px-5 py-3.5 text-xs font-bold text-[hsl(var(--primary-foreground))] shadow-xl shadow-[hsl(var(--primary)/.2)] transition hover:-translate-y-0.5" data-testid="button-landing-sign-in">
              Sign in to your space <ArrowRight size={15} className="transition group-hover:translate-x-0.5" />
            </button>
            <button onClick={() => setLocation('/sign-up')} className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card)/.7)] px-5 py-3.5 text-xs font-bold transition hover:-translate-y-0.5 hover:bg-[hsl(var(--card))]" data-testid="button-landing-sign-up">
              Create an account
            </button>
          </div>
          <div className="mt-10 flex flex-wrap gap-x-6 gap-y-3 text-[10px] font-semibold text-[hsl(var(--muted-foreground))]">
            <span className="flex items-center gap-2"><ShieldCheck size={14} className="text-[hsl(var(--chart-2))]" /> Private by design</span>
            <span className="flex items-center gap-2"><Sparkles size={14} className="text-[hsl(var(--accent-foreground))]" /> Six perspectives, one clear read</span>
          </div>
        </section>

        <section className="relative mx-auto w-full max-w-[520px] lg:ml-auto">
          <div className="absolute -right-6 -top-8 size-32 rounded-full border-[20px] border-[hsl(var(--accent)/.24)] blur-[1px]" />
          <div className="absolute -bottom-8 -left-8 size-24 rounded-full bg-[hsl(var(--secondary)/.55)] blur-[1px]" />
          <div className="relative rounded-[30px] border border-[hsl(var(--border)/.75)] bg-[hsl(var(--card)/.82)] p-5 shadow-[0_30px_80px_hsl(246_28%_19%/.12)] backdrop-blur sm:p-7 fade-up fade-up-delay-2">
            <div className="mb-8 flex items-center justify-between">
              <div>
                <p className="mono-font text-[10px] uppercase tracking-[.18em] text-[hsl(var(--muted-foreground))]">Decision preview</p>
                <p className="mt-1 text-xs font-bold">A calmer way to choose</p>
              </div>
              <span className="rounded-full bg-[hsl(var(--secondary))] px-2.5 py-1 text-[9px] font-bold text-[hsl(var(--secondary-foreground))]">Private space</span>
            </div>
            <div className="rounded-[22px] bg-[hsl(var(--sidebar))] p-5 text-[hsl(var(--sidebar-foreground))] sm:p-6">
              <div className="mb-8 flex items-center gap-2">
                <span className="size-2 rounded-full bg-[hsl(var(--sidebar-primary))] pulse-dot" />
                <span className="mono-font text-[9px] uppercase tracking-[.16em] text-[hsl(var(--sidebar-foreground)/.55)]">Active thread</span>
              </div>
              <p className="display-font text-[clamp(24px,3vw,34px)] font-bold leading-[1.06] tracking-[-.055em]">Should I make the brave choice?</p>
              <div className="mt-7 border-l-2 border-[hsl(var(--sidebar-primary)/.7)] pl-4">
                <p className="mono-font text-[9px] uppercase tracking-[.16em] text-[hsl(var(--sidebar-foreground)/.42)]">Decision agent</p>
                <p className="mt-2 text-[13px] font-semibold leading-6 text-[hsl(var(--sidebar-foreground)/.78)]">Move toward the option that gives you more agency, with one sensible guardrail.</p>
              </div>
            </div>
            <div className="mt-4 grid grid-cols-3 gap-2">
              {['Context', 'Trade-off', 'Regret'].map((label, index) => (
                <div key={label} className="rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--background)/.7)] p-3">
                  <span className={`mb-4 grid size-7 place-items-center rounded-lg ${index === 0 ? 'bg-[hsl(var(--primary)/.12)] text-[hsl(var(--primary))]' : index === 1 ? 'bg-[hsl(var(--secondary))] text-[hsl(var(--secondary-foreground))]' : 'bg-[hsl(var(--accent)/.22)] text-[hsl(var(--accent-foreground))]'}`}><Sparkles size={13} /></span>
                  <p className="text-[10px] font-bold">{label}</p>
                  <p className="mt-1 text-[9px] leading-4 text-[hsl(var(--muted-foreground))]">{index === 0 ? 'What is true' : index === 1 ? 'What it costs' : 'Future you'}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}

function SignInPage() {
  return (
    <main className="auth-shell flex min-h-[100dvh] items-center justify-center px-4 py-8">
      <div className="w-full max-w-[440px]">
        <div className="mb-6 text-center">
          <a href={basePath || '/'} className="inline-flex items-center gap-3">
            <img src={`${basePath}/logo.svg`} alt="DecisionOS" className="size-10 rounded-[13px] shadow-lg shadow-[#29213E]/10" />
            <span className="display-font text-lg font-bold tracking-[-.045em]">DecisionOS</span>
          </a>
        </div>
        <SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} />
        <p className="mt-6 text-center text-[10px] font-semibold text-[hsl(var(--muted-foreground))]">Your thinking stays yours. Always.</p>
      </div>
    </main>
  );
}

function SignUpPage() {
  return (
    <main className="auth-shell flex min-h-[100dvh] items-center justify-center px-4 py-8">
      <div className="w-full max-w-[440px]">
        <div className="mb-6 text-center">
          <a href={basePath || '/'} className="inline-flex items-center gap-3">
            <img src={`${basePath}/logo.svg`} alt="DecisionOS" className="size-10 rounded-[13px] shadow-lg shadow-[#29213E]/10" />
            <span className="display-font text-lg font-bold tracking-[-.045em]">DecisionOS</span>
          </a>
        </div>
        <SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} />
        <p className="mt-6 text-center text-[10px] font-semibold text-[hsl(var(--muted-foreground))]">A clearer next step starts here.</p>
      </div>
    </main>
  );
}

function HomeRedirect() {
  return (
    <>
      <Show when="signed-in">
        <DecisionPortal />
      </Show>
      <Show when="signed-out">
        <AuthLanding />
      </Show>
    </>
  );
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();

  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        signIn: {
          start: {
            title: 'Welcome back',
            subtitle: 'Sign in to return to your decision space',
          },
        },
        signUp: {
          start: {
            title: 'Create your decision space',
            subtitle: 'Start making the next step clearer',
          },
        },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <Switch>
        <Route path="/" component={HomeRedirect} />
        <Route path="/sign-in/*?" component={SignInPage} />
        <Route path="/sign-up/*?" component={SignUpPage} />
        <Route component={HomeRedirect} />
      </Switch>
    </ClerkProvider>
  );
}

function stripBase(path: string) {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || '/'
    : path;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  return <ErrorBoundary resetKey="decision-os">{children}</ErrorBoundary>;
}

function AppRoot() {
  if (!clerkPubKey) {
    throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY in environment.');
  }

  return (
    <WouterRouter base={basePath}>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <RoutedErrorBoundary>
            <ClerkProviderWithRoutes />
          </RoutedErrorBoundary>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </WouterRouter>
  );
}

export default AppRoot;