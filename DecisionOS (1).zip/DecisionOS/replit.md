# DecisionOS

DecisionOS is a personal decision-making companion that turns uncertainty into a clear, explainable next step and learns from the outcomes.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/decision-os/src/App.tsx` — product shell, local decision state, agent synthesis, history, regret tracker, patterns, and autonomous suggestions.
- `artifacts/decision-os/src/index.css` — DecisionOS visual system and responsive layout primitives.
- `artifacts/decision-os/.replit-artifact/artifact.toml` — artifact routing and web workflow metadata.

## Architecture decisions

- The first product build is frontend-first and local-state backed so the full decision lifecycle is usable immediately; Clerk now gates the private workspace while a server-backed decision store remains a follow-up.
- Decision synthesis is expressed as six distinct perspectives (Context, Preference, Trade-off, Regret, Devil's Advocate, Decision) so recommendations stay explainable instead of feeling like a black box.
- Autonomous suggestions are explicitly low-risk and require a confirmation step before they are added to the user's decision trail.
- The app uses a warm parchment, indigo, apricot, and mint visual language to make reflection feel personal rather than clinical.

## Product

- Active decision workspace with recommendation, confidence, reasons, alternative, and “why not the other option?”
- New decision capture with options and what-matters context.
- Decision history and outcome logging with good / neutral / bad feedback.
- Regret tracking, personal decision patterns, and quality analytics.
- Autonomous decision suggestions with a visible low-risk safety boundary and user confirmation.
- Branded Clerk sign-in and sign-up flow before entering the private workspace.

## User preferences

- No user-specific preferences recorded yet.

## Gotchas

- The app currently stores its decision trail in browser localStorage; the authenticated account is ready for a future user-scoped backend store.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
